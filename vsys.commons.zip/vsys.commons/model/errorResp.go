package model

type ErrorResp struct {
	ErrCode    int
	ErrMessage string
}
