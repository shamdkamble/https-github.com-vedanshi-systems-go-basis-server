package model

type MobileNoForInitiatingRegistrationForUser struct {
	MobileNo string `json:"mobileNo"`
}
